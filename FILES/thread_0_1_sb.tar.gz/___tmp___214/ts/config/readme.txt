Contains the minimum set of config file and setting to allow trafficserver to start in a usable way.
The goal is to remove the need for any of these files to exist.
ip_allow.yaml is needed to allow tests the minimum access to traffic_server.
storage.config needs to exist for now.
