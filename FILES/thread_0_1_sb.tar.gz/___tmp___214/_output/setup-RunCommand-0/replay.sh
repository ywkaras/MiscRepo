#!/bin/bash

export TS_ROOT="/Users/wkaras/REPOS/TS2/tests/_sandbox/___tmp___214/ts"
export PROXY_CONFIG_BIN_PATH="bin"
export PATH="/Users/wkaras/REPOS/TS2/tests/_sandbox/___tmp___214/ts/bin:/root/.local/share/virtualenvs/tests-fabadr29/bin:/opt/rh/devtoolset-8/root/usr/bin:/Users/wkaras/DOCKER/bin:/opt/oath/libcurl/7.66/bin:/opt/oath/openssl/1.1.1/bin:/usr/local/bin:/opt/rh/httpd24/root/usr/bin:/opt/rh/httpd24/root/usr/sbin:/root/.conan/data/cmake_installer/3.13.0/conan/stable/package/44fcf6b9a7fb86b2586303e3db40189d3b511830/bin:/Users/wkaras/REPOS/BUILD/build-env/bin:/opt/rh/rh-python36/root/usr/bin:/opt/rh/devtoolset-8/root/usr/bin:/usr/local/git/bin:/opt/rh/httpd24/root/usr/bin:/opt/rh/httpd24/root/usr/sbin:/opt/rh/devtoolset-8/root/usr/bin:/sbin:/bin:/usr/sbin:/usr/bin:/home/y/bin:/home/y/sbin"
export PROXY_CONFIG_CONFIG_DIR="/Users/wkaras/REPOS/TS2/tests/_sandbox/___tmp___214/ts/config"
export PROXY_CONFIG_BODY_FACTORY_TEMPLATE_SETS_DIR="/Users/wkaras/REPOS/TS2/tests/_sandbox/___tmp___214/ts/config/body_factory"
export PROXY_CONFIG_CACHE_DIR="/Users/wkaras/REPOS/TS2/tests/_sandbox/___tmp___214/ts/cache"
export PROXY_CONFIG_PLUGIN_PLUGIN_DIR="/Users/wkaras/REPOS/TS2/tests/_sandbox/___tmp___214/ts/plugin"
export PROXY_CONFIG_LOG_LOGFILE_DIR="/Users/wkaras/REPOS/TS2/tests/_sandbox/___tmp___214/ts/log"
export PROXY_CONFIG_LOCAL_STATE_DIR="/Users/wkaras/REPOS/TS2/tests/_sandbox/___tmp___214/ts/runtime"
export PROXY_CONFIG_HOSTDB_STORAGE_PATH="/Users/wkaras/REPOS/TS2/tests/_sandbox/___tmp___214/ts/runtime"
export PROXY_CONFIG_SNAPSHOT_DIR="/Users/wkaras/REPOS/TS2/tests/_sandbox/___tmp___214/ts/config/snapshots"
export PROXY_CONFIG_SSL_DIR="/Users/wkaras/REPOS/TS2/tests/_sandbox/___tmp___214/ts/ssl"
export PROXY_CONFIG_STORAGE_DIR="/Users/wkaras/REPOS/TS2/tests/_sandbox/___tmp___214/ts/storage"
export PROXY_CONFIG_PROCESS_MANAGER_MGMT_PORT="61642"
export PROXY_CONFIG_ADMIN_SYNTHETIC_PORT="61643"
export PROXY_CONFIG_ADMIN_AUTOCONF_PORT="61643"
TS_ROOT=/Users/wkaras/TSX/TS2 /Users/wkaras/TSX/TS2/bin/traffic_layout init --force --copy-style soft --path /Users/wkaras/REPOS/TS2/tests/_sandbox/___tmp___214/ts --layout=/Users/wkaras/REPOS/TS2/tests/gold_tests/autest-site/autest_runroot_layout.yml
